
export default function loading() {
    return (
        <>
            <div className="preloader" id="preloader">
                <div className="loader" />
            </div>
        </>
    )
}
