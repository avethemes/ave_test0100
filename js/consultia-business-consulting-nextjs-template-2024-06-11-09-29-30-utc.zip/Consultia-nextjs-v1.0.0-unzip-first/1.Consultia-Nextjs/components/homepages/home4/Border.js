

export default function Border() {
    return (
        <>
            <div className="container">
                <div className="row">
                    <div className="col-12">
                        <div className="border1" />
                    </div>
                </div>
            </div>

        </>
    )
}
